#ifndef SERVER_H
#define SERVER_H

#include <QMainWindow>
#include <QtGui>
#include <QWidget>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QGroupBox>
#include <QTextEdit>
#include <QDateEdit>
#include <QVBoxLayout>
#include <QFormLayout>
#include <QMessageBox>
#include <string.h>


/*les includes pour la communication*/
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8888


class FenPrincipale : public QWidget
{
    Q_OBJECT


    public:
        FenPrincipale();

    private slots:
         void envoi();
    private:
         QLineEdit *textEnvoi;
         QPushButton *envoyer;
         QPushButton *quitter;
         int newSocket;
};

#endif // SERVER_H
