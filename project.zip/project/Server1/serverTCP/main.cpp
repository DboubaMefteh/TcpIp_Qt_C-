#include "server.h"
#include <QApplication>


int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    FenPrincipale fenetre;
    //fenetre.show();

    return app.exec();
}
