#include "server.h"

FenPrincipale::FenPrincipale()
{

    // Groupe : Definition de la classe
    textEnvoi = new QLineEdit;
    QFormLayout *champLayout = new QFormLayout;
    champLayout->addRow("&Message :", textEnvoi);


    QGroupBox *groupChamp = new QGroupBox("envoi de mesg");
    groupChamp->setLayout(champLayout);


    // Layout : boutons du bas (envoyer, quitter...)
        envoyer = new QPushButton("&Envoyer !");
        quitter = new QPushButton("&Quitter");

        QHBoxLayout *boutonsLayout = new QHBoxLayout;
        boutonsLayout->setAlignment(Qt::AlignRight);

        boutonsLayout->addWidget(envoyer);
        boutonsLayout->addWidget(quitter);


    // Definition du layout principal, du titre de la fenetre, etc.

       QVBoxLayout *layoutPrincipal = new QVBoxLayout;
       layoutPrincipal->addWidget(groupChamp);
       layoutPrincipal->addLayout(boutonsLayout);



       setLayout(layoutPrincipal);
       setWindowTitle("Basic Application");
       //setWindowIcon(QIcon("icone.png"));
       resize(400, 450);


       // Connexions des signaux et des slots
       connect(quitter, SIGNAL(clicked()), qApp, SLOT(quit()));
       connect(envoyer, SIGNAL(clicked()), this, SLOT(envoi()));

       //maintenant pour la configuration

       int ServerSocket=socket(PF_INET, SOCK_STREAM, 0);

       //configuration de server
       struct sockaddr_in serverAddr;
       struct sockaddr_in newAddr;
       serverAddr.sin_family = AF_INET;
       serverAddr.sin_port = htons(PORT);
       serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

       //Bind de connexion

       bind(ServerSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
       listen(ServerSocket, 5);
       socklen_t addr_size;
       newSocket = accept(ServerSocket, (struct sockaddr*)&newAddr, &addr_size);
       show();


}

void FenPrincipale::envoi()
{
    // On verifie que le message n'est pas vide, sinon on arrete
    if (textEnvoi->text().isEmpty())
    {
        QMessageBox::critical(this, "Erreur", "Veuillez entrer un msg");
        return; //
    }
    QString code=textEnvoi->text();
    QByteArray ba = code.toLocal8Bit();
    char*Buffer=ba.data();
    send(newSocket, Buffer, 1024, 0);


}
