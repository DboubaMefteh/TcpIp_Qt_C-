#include "FenetrePrincipale.h"

client::client(QWidget *parent)
    : QMainWindow(parent)
{

}

client::~client()
{

}
