//#include "client.h"
#include <QApplication>
#include <QDialog>
#include <QtWidgets>
#include <QWidget>
#include <QPushButton>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define PORT 8888 //port de connexion

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);


    /*Client TCP*/
        char Buffer[1024];
        int clientSocket=socket(PF_INET, SOCK_STREAM, 0);
        //configuration de server
        struct sockaddr_in serverAddr;
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(PORT);
        serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
        QWidget fenetre;


        //pour etablir la connexion
        connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
        recv(clientSocket, Buffer, 1024, 0);
        QString a="";

        for (int i=0;i<(int)strlen(Buffer);i++) {
            a+=QChar(Buffer[i]);

        }

        QGroupBox *groupbox = new QGroupBox("Le msg", &fenetre);
       QTextEdit* msgRecu = new QTextEdit();

        msgRecu->setPlainText(a);


        QPushButton *fermer  = new QPushButton("fermer");
        QObject::connect(fermer, SIGNAL(clicked()), qApp, SLOT(quit()));
        QVBoxLayout *vbox = new QVBoxLayout;

        vbox->addWidget(msgRecu);
        vbox->addWidget(fermer);

        groupbox->setLayout(vbox);
        groupbox->move(5, 5);
        groupbox->resize(400, 450);
        fenetre.show();


        return app.exec();
    }


